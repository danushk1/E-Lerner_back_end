<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class subject_matter extends Model
{
    //
}
