<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class user_to_subject extends Model
{
    //
}
