<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class subject_main_content extends Model
{
    //
}
